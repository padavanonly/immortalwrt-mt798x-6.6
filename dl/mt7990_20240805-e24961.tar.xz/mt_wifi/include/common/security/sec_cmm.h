#ifndef SEC_CMM_H
#define SEC_CMM_H

#include "rtmp_type.h"
#include "eht.h"
#include "security/dot11i_wpa.h"

#ifdef DOT11W_PMF_SUPPORT
#include "security/pmf_cmm.h"
#endif /* DOT11W_PMF_SUPPORT */


#include "security/owe_cmm.h"

#ifdef SUPP_SAE_SUPPORT
#include "security/sae_cmm.h"
#endif

/* Key Related definitions */
#define SEC_SHARE_KEY_NUM 4
#define SEC_KEY_NUM SEC_SHARE_KEY_NUM
#define SEC_RSNIE_NUM  2 /* Support  IE, 1:WPA1_IE or WAPI_IE, 2: WPA2_IE */

#define WFA_KDE_SAE_PK 0x1f
#define WFA_KDE_TTI 0x20
#define MAX_OCI_LEN 9
#define MIN_OCI_LEN 6

#define EID_EXT_OCI 54

typedef enum _SEC_RSNIE_TYPE {
	SEC_RSNIE_NONE,
	SEC_RSNIE_WPA1_IE,
	SEC_RSNIE_WPA2_IE,
	SEC_RSNIE_MAX /* Not a real mode, defined as upper bound */
} SEC_RSNIE_TYPE, *PSEC_RSNIE_TYPE;


/* 802.11 authentication and key management */
typedef enum _SEC_AKM_MODE {
	SEC_AKM_OPEN,
	SEC_AKM_SHARED,
	SEC_AKM_AUTOSWITCH,
	SEC_AKM_WPA1, /* Enterprise security over 802.1x */
	SEC_AKM_WPA1PSK,
	SEC_AKM_WPANone, /* For Win IBSS, directly PTK, no handshark */
	SEC_AKM_WPA2, /* Enterprise security over 802.1x */
	SEC_AKM_WPA2PSK,
	SEC_AKM_FT_WPA2,
	SEC_AKM_FT_WPA2PSK,
	SEC_AKM_WPA2_SHA256,
	SEC_AKM_WPA2PSK_SHA256,
	SEC_AKM_TDLS,
	SEC_AKM_SAE_SHA256,
	SEC_AKM_FT_SAE_SHA256,
	SEC_AKM_SUITEB_SHA256,
	SEC_AKM_SUITEB_SHA384,
	SEC_AKM_FT_WPA2_SHA384,
	SEC_AKM_WAICERT, /* WAI certificate authentication */
	SEC_AKM_WAIPSK, /* WAI pre-shared key */
	SEC_AKM_OWE,
	SEC_AKM_FILS_SHA256,
	SEC_AKM_FILS_SHA384,
	SEC_AKM_WPA3, /* WPA3(ent) = WPA2(ent) + PMF MFPR=1 => WPA3 code flow is same as WPA2, the usage of SEC_AKM_WPA3 is to force pmf on */
#ifdef CONFIG_HOTSPOT_R3
	SEC_AKM_OSEN,
#endif
	SEC_AKM_DPP,
	SEC_AKM_SAE_EXT,
	SEC_AKM_FT_SAE_EXT,
	SEC_AKM_MAX /* Not a real mode, defined as upper bound */
} SEC_AKM_MODE, *PSEC_AKM_MODE;

enum SEC_KEY_DERI_ALG {
	SEC_KEY_DERI_SHA1 = 0,
	SEC_KEY_DERI_SHA256,
	SEC_KEY_DERI_SHA384,
	SEC_KEY_DERI_SHA512
};

enum RSN_FIELD {
	RSN_FIELD_NONE = 0,
	RSN_FIELD_GROUP_CIPHER,
	RSN_FIELD_PAIRWISE_CIPHER,
	RSN_FIELD_AKM,
	RSN_FIELD_RSN_CAP,
	RSN_FIELD_PMKID,
	RSN_FIELD_GROUP_MGMT_CIPHER,
	RSN_FIELD_EXTENSIBLE_ELE
};


#define GET_SEC_AKM(_SecConfig)              ((_SecConfig)->AKMMap)
#define CLEAR_SEC_AKM(_AKMMap)              (_AKMMap = 0x0)
#define CLEAR_NONFT_AKM(_AKMMap)              (_AKMMap &= ~((1 << SEC_AKM_WPA2) | (1 << SEC_AKM_WPA2PSK) |\
						(1 << SEC_AKM_WPA2_SHA256) | (1 << SEC_AKM_WPA2PSK_SHA256) |\
						(1 << SEC_AKM_SAE_SHA256) | (1 << SEC_AKM_SUITEB_SHA384)))
#define SET_AKM_OPEN(_AKMMap)           (_AKMMap |= (1 << SEC_AKM_OPEN))
#define SET_AKM_SHARED(_AKMMap)       (_AKMMap |= (1 << SEC_AKM_SHARED))
#define SET_AKM_AUTOSWITCH(_AKMMap)       (_AKMMap |= (1 << SEC_AKM_AUTOSWITCH))
#define SET_AKM_WPA1(_AKMMap)          (_AKMMap |= (1 << SEC_AKM_WPA1))
#define SET_AKM_WPA1PSK(_AKMMap)    (_AKMMap |= (1 << SEC_AKM_WPA1PSK))
#define SET_AKM_WPANONE(_AKMMap)  (_AKMMap |= (1 << SEC_AKM_WPANone))
#define SET_AKM_WPA2(_AKMMap)          (_AKMMap |= (1 << SEC_AKM_WPA2))
#define SET_AKM_WPA2PSK(_AKMMap)    (_AKMMap |= (1 << SEC_AKM_WPA2PSK))
#define SET_AKM_FT_WPA2(_AKMMap)                  (_AKMMap |= (1 << SEC_AKM_FT_WPA2))
#define SET_AKM_FT_WPA2PSK(_AKMMap)            (_AKMMap |= (1 << SEC_AKM_FT_WPA2PSK))
#define SET_AKM_WPA2_SHA256(_AKMMap)         (_AKMMap |= (1 << SEC_AKM_WPA2_SHA256))
#define SET_AKM_WPA2PSK_SHA256(_AKMMap)   (_AKMMap |= (1 << SEC_AKM_WPA2PSK_SHA256))
#define SET_AKM_TDLS(_AKMMap)                           (_AKMMap |= (1 << SEC_AKM_TDLS))
#define SET_AKM_SAE_SHA256(_AKMMap)              (_AKMMap |= (1 << SEC_AKM_SAE_SHA256))
#define SET_AKM_FT_SAE_SHA256(_AKMMap)        (_AKMMap |= (1 << SEC_AKM_FT_SAE_SHA256))
#define SET_AKM_SUITEB_SHA256(_AKMMap)         (_AKMMap |= (1 << SEC_AKM_SUITEB_SHA256))
#define SET_AKM_SUITEB_SHA384(_AKMMap)         (_AKMMap |= (1 << SEC_AKM_SUITEB_SHA384))
#define SET_AKM_FT_WPA2_SHA384(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_FT_WPA2_SHA384))
#define SET_AKM_OWE(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_OWE))
#ifdef OCE_FILS_SUPPORT
#define SET_AKM_FILS_SHA256(_AKMMap)                (_AKMMap |= (1 << SEC_AKM_FILS_SHA256))
#define SET_AKM_FILS_SHA384(_AKMMap)                (_AKMMap |= (1 << SEC_AKM_FILS_SHA384))
#endif /* OCE_FILS_SUPPORT */
#define SET_AKM_WPA3(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_WPA3))
#ifdef CONFIG_HOTSPOT_R3
#define SET_AKM_OSEN(_AKMMap)           (_AKMMap |= (1 << SEC_AKM_OSEN))
#endif
#define SET_AKM_DPP(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_DPP))
#define SET_AKM_SAE_EXT(_AKMMap)                (_AKMMap |= (1 << SEC_AKM_SAE_EXT))
#define SET_AKM_FT_SAE_EXT(_AKMMap)          (_AKMMap |= (1 << SEC_AKM_FT_SAE_EXT))

#define IS_AKM_OPEN(_AKMMap)                           ((_AKMMap & (1 << SEC_AKM_OPEN)) > 0)
#define IS_AKM_SHARED(_AKMMap)                       ((_AKMMap & (1 << SEC_AKM_SHARED)) > 0)
#define IS_AKM_AUTOSWITCH(_AKMMap)              ((_AKMMap & (1 << SEC_AKM_AUTOSWITCH)) > 0)
#define IS_AKM_WPA1(_AKMMap)                           ((_AKMMap & (1 << SEC_AKM_WPA1)) > 0)
#define IS_AKM_WPA1PSK(_AKMMap)                    ((_AKMMap & (1 << SEC_AKM_WPA1PSK)) > 0)
#define IS_AKM_WPANONE(_AKMMap)                  ((_AKMMap & (1 << SEC_AKM_WPANone)) > 0)
#define IS_AKM_WPA2(_AKMMap)                          ((_AKMMap & (1 << SEC_AKM_WPA2)) > 0)
#define IS_AKM_WPA2PSK(_AKMMap)                    ((_AKMMap & (1 << SEC_AKM_WPA2PSK)) > 0)
#define IS_AKM_FT_WPA2(_AKMMap)                     ((_AKMMap & (1 << SEC_AKM_FT_WPA2)) > 0)
#define IS_AKM_FT_WPA2PSK(_AKMMap)              ((_AKMMap & (1 << SEC_AKM_FT_WPA2PSK)) > 0)
#define IS_AKM_WPA2_SHA256(_AKMMap)            ((_AKMMap & (1 << SEC_AKM_WPA2_SHA256)) > 0)
#define IS_AKM_WPA2PSK_SHA256(_AKMMap)      ((_AKMMap & (1 << SEC_AKM_WPA2PSK_SHA256)) > 0)
#define IS_AKM_TDLS(_AKMMap)                             ((_AKMMap & (1 << SEC_AKM_TDLS)) > 0)
#define IS_AKM_SAE_SHA256(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_SAE_SHA256)) > 0)
#define IS_AKM_FT_SAE_SHA256(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_FT_SAE_SHA256)) > 0)
#define IS_AKM_SUITEB_SHA256(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_SUITEB_SHA256)) > 0)
#define IS_AKM_SUITEB_SHA384(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_SUITEB_SHA384)) > 0)
#define IS_AKM_FT_WPA2_SHA384(_AKMMap)      ((_AKMMap & (1 << SEC_AKM_FT_WPA2_SHA384)) > 0)
#define IS_AKM_WPA3(_AKMMap)	 ((_AKMMap & (1 << SEC_AKM_WPA3)) > 0)
#ifdef CONFIG_HOTSPOT_R3
#define IS_AKM_OSEN(_AKMMap)     ((_AKMMap & (1 << SEC_AKM_OSEN)) > 0)
#endif
#define IS_AKM_DPP(_AKMMap)      ((_AKMMap & (1 << SEC_AKM_DPP)) > 0)
#define IS_AKM_SAE_EXT(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_SAE_EXT)) > 0)
#define IS_AKM_FT_SAE_EXT(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_FT_SAE_EXT)) > 0)
#define IS_AKM_DPP_ONLY(_AKMMap)      (_AKMMap == (1 << SEC_AKM_DPP))


#if defined(DOT11_SUITEB_SUPPORT) || defined(HOSTAPD_SUITEB_SUPPORT)
#define IS_AKM_WPA3_192BIT(_AKMMap)	(IS_AKM_SUITEB_SHA384(_AKMMap))
#define SET_AKM_WPA3_192BIT(_AKMMap)	SET_AKM_SUITEB_SHA384(_AKMMap)
#else
#define IS_AKM_WPA3_192BIT(_AKMMap)	(FALSE)
#define SET_AKM_WPA3_192BIT(_AKMMap)
#endif

#ifdef OCE_FILS_SUPPORT
#define IS_AKM_FILS_SHA256(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_FILS_SHA256)) > 0)
#define IS_AKM_FILS_SHA384(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_FILS_SHA384)) > 0)
#define IS_AKM_FILS(_AKMMap)     (IS_AKM_FILS_SHA256(_AKMMap)  \
								|| IS_AKM_FILS_SHA384(_AKMMap))

#define IS_AKM_FILS_Entry(_Entry)     (IS_AKM_FILS_SHA256((_Entry)->SecConfig.AKMMap)  \
									 || IS_AKM_FILS_SHA384((_Entry)->SecConfig.AKMMap))

#endif /* OCE_FILS_SUPPORT */
#if defined(DOT11_SAE_SUPPORT) || defined(HOSTAPD_SAE_SUPPORT)
#define IS_AKM_WPA3PSK(_AKMMap) (IS_AKM_SAE_SHA256(_AKMMap) \
									|| IS_AKM_SAE_EXT(_AKMMap))
#define SET_AKM_WPA3PSK(_AKMMap) (_AKMMap |= (1 << SEC_AKM_SAE_SHA256) | (1 << SEC_AKM_SAE_EXT))
#else
#define IS_AKM_WPA3PSK(_AKMMap) (FALSE)
#define SET_AKM_WPA3PSK(_AKMMap)
#endif

#if defined(CONFIG_OWE_SUPPORT) || defined(HOSTAPD_OWE_SUPPORT) || defined(SUPP_OWE_SUPPORT)
#define IS_AKM_OWE(_AKMMap) ((_AKMMap & (1 << SEC_AKM_OWE)) > 0)
#else
#define IS_AKM_OWE(_AKMMap) (FALSE)
#endif

#define IS_AKM_WPA3PSK_ONLY(_AKMMap)                          (_AKMMap == (1 << SEC_AKM_SAE_SHA256))
#define IS_AKM_WPA2PSK_ONLY(_AKMMap)                          (_AKMMap == (1 << SEC_AKM_WPA2PSK))

#define IS_AKM_SAE(_AKMMap)     (IS_AKM_SAE_SHA256(_AKMMap)  \
				|| IS_AKM_FT_SAE_SHA256(_AKMMap)  \
				|| IS_AKM_SAE_EXT(_AKMMap)  \
				|| IS_AKM_FT_SAE_EXT(_AKMMap))


#define IS_AKM_FT_SAE(_AKMMap)     (IS_AKM_FT_SAE_SHA256(_AKMMap)  \
				|| IS_AKM_FT_SAE_EXT(_AKMMap))

#define IS_AKM_PSK(_AKMMap)     (IS_AKM_WPA1PSK(_AKMMap)  \
				|| IS_AKM_WPA2PSK(_AKMMap)\
				|| IS_AKM_WPA3PSK(_AKMMap)\
				|| IS_AKM_DPP(_AKMMap)\
				|| IS_AKM_OWE(_AKMMap))

#define IS_AKM_1X(_AKMMap)     (IS_AKM_WPA1(_AKMMap)  \
								|| IS_AKM_WPA2(_AKMMap)\
								|| IS_AKM_WPA3_192BIT(_AKMMap))


#define IS_AKM_WPA_CAPABILITY(_AKMMap)     (IS_AKM_WPA1(_AKMMap)  \
		|| IS_AKM_WPA1PSK(_AKMMap) \
		|| IS_AKM_WPANONE(_AKMMap) \
		|| IS_AKM_WPA2(_AKMMap) \
		|| IS_AKM_WPA2PSK(_AKMMap) \
		|| IS_AKM_WPA2_SHA256(_AKMMap) \
		|| IS_AKM_WPA2PSK_SHA256(_AKMMap)\
		|| IS_AKM_WPA3_192BIT(_AKMMap)\
		|| IS_AKM_WPA3PSK(_AKMMap)\
		|| IS_AKM_DPP(_AKMMap)\
		|| IS_AKM_OWE(_AKMMap))

#define IS_AKM_SHA256(_AKMMap)     (IS_AKM_FT_WPA2(_AKMMap)  \
		|| IS_AKM_FT_WPA2PSK(_AKMMap) \
		|| IS_AKM_WPA2PSK_SHA256(_AKMMap) \
		|| IS_AKM_WPA2_SHA256(_AKMMap) \
		|| IS_AKM_SAE_SHA256(_AKMMap) \
		|| IS_AKM_FT_SAE_SHA256(_AKMMap) \
		|| IS_AKM_SUITEB_SHA256(_AKMMap))

#define IS_AKM_SHA384(_AKMMap)     (IS_AKM_SUITEB_SHA384(_AKMMap) \
		|| IS_AKM_FT_WPA2_SHA384(_AKMMap)  \
		|| IS_AKM_SAE_EXT(_AKMMap))

typedef enum _SEC_CIPHER_MODE {
	SEC_CIPHER_NONE,
	SEC_CIPHER_WEP40,
	SEC_CIPHER_WEP104,
	SEC_CIPHER_WEP128,
	SEC_CIPHER_TKIP,
	SEC_CIPHER_CCMP128,
	SEC_CIPHER_CCMP256,
	SEC_CIPHER_GCMP128,
	SEC_CIPHER_GCMP256,
	SEC_CIPHER_BIP_CMAC128,
	SEC_CIPHER_BIP_CMAC256,
	SEC_CIPHER_BIP_GMAC128,
	SEC_CIPHER_BIP_GMAC256,
	SEC_CIPHER_WPI_SMS4, /* WPI SMS4 support */
	SEC_CIPHER_MAX /* Not a real mode, defined as upper bound */
} SEC_CIPHER_MODE;

#define CLEAR_PAIRWISE_CIPHER(_SecConfig)      ((_SecConfig)->PairwiseCipher = 0x0)
#define CLEAR_GROUP_CIPHER(_SecConfig)          ((_SecConfig)->GroupCipher = 0x0)
#define CLEAR_INTEGRITY_GROUP_CIPHER(_SecConfig)          ((_SecConfig)->PmfCfg.igtk_cipher = 0x0)
#define CLEAR_BEACON_INTEGRITY_GROUP_CIPHER(_SecConfig)          ((_SecConfig)->bcn_prot_cfg.bigtk_cipher = 0x0)
#define GET_PAIRWISE_CIPHER(_SecConfig)         ((_SecConfig)->PairwiseCipher)
#define GET_GROUP_CIPHER(_SecConfig)              ((_SecConfig)->GroupCipher)
#define GET_INTEGRITY_GROUP_CIPHER(_SecConfig)      ((_SecConfig)->PmfCfg.igtk_cipher)
#define GET_BEACON_INTEGRITY_GROUP_CIPHER(_SecConfig)      ((_SecConfig)->bcn_prot_cfg.bigtk_cipher)
#define CLEAR_CIPHER(_cipher)					(_cipher  = 0x0)
#define SET_CIPHER_NONE(_cipher)               (_cipher |= (1 << SEC_CIPHER_NONE))
#define SET_CIPHER_WEP40(_cipher)             (_cipher |= (1 << SEC_CIPHER_WEP40))
#define SET_CIPHER_WEP104(_cipher)           (_cipher |= (1 << SEC_CIPHER_WEP104))
#define SET_CIPHER_WEP128(_cipher)           (_cipher |= (1 << SEC_CIPHER_WEP128))
#define SET_CIPHER_WEP(_cipher)                 (_cipher |= (1 << SEC_CIPHER_WEP40) | (1 << SEC_CIPHER_WEP104) | (1 << SEC_CIPHER_WEP128))
#define SET_CIPHER_TKIP(_cipher)                  (_cipher |= (1 << SEC_CIPHER_TKIP))
#define SET_CIPHER_CCMP128(_cipher)          (_cipher |= (1 << SEC_CIPHER_CCMP128))
#define SET_CIPHER_CCMP256(_cipher)          (_cipher |= (1 << SEC_CIPHER_CCMP256))
#define SET_CIPHER_GCMP128(_cipher)         (_cipher |= (1 << SEC_CIPHER_GCMP128))
#define SET_CIPHER_GCMP256(_cipher)         (_cipher |= (1 << SEC_CIPHER_GCMP256))
#define SET_CIPHER_BIP_CMAC128(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_CMAC128))
#define SET_CIPHER_BIP_CMAC256(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_CMAC256))
#define SET_CIPHER_BIP_GMAC128(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_GMAC128))
#define SET_CIPHER_BIP_GMAC256(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_GMAC256))

#define IS_CIPHER_NONE(_Cipher)          (((_Cipher) & (1 << SEC_CIPHER_NONE)) > 0)
#define IS_CIPHER_WEP40(_Cipher)          (((_Cipher) & (1 << SEC_CIPHER_WEP40)) > 0)
#define IS_CIPHER_WEP104(_Cipher)        (((_Cipher) & (1 << SEC_CIPHER_WEP104)) > 0)
#define IS_CIPHER_WEP128(_Cipher)        (((_Cipher) & (1 << SEC_CIPHER_WEP128)) > 0)
#define IS_CIPHER_WEP(_Cipher)              (((_Cipher) & ((1 << SEC_CIPHER_WEP40) | (1 << SEC_CIPHER_WEP104) | (1 << SEC_CIPHER_WEP128))) > 0)
#define IS_CIPHER_TKIP(_Cipher)              (((_Cipher) & (1 << SEC_CIPHER_TKIP)) > 0)
#define IS_CIPHER_WEP_TKIP_ONLY(_Cipher)     ((IS_CIPHER_WEP(_Cipher) || IS_CIPHER_TKIP(_Cipher)) && (_Cipher < (1 << SEC_CIPHER_CCMP128)))
#define IS_CIPHER_CCMP128(_Cipher)      (((_Cipher) & (1 << SEC_CIPHER_CCMP128)) > 0)
#define IS_CIPHER_CCMP256(_Cipher)      (((_Cipher) & (1 << SEC_CIPHER_CCMP256)) > 0)
#define IS_CIPHER_GCMP128(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_GCMP128)) > 0)
#define IS_CIPHER_GCMP256(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_GCMP256)) > 0)
#define IS_CIPHER_BIP_CMAC128(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_CMAC128)) > 0)
#define IS_CIPHER_BIP_CMAC256(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_CMAC256)) > 0)
#define IS_CIPHER_BIP_GMAC128(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_GMAC128)) > 0)
#define IS_CIPHER_BIP_GMAC256(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_GMAC256)) > 0)

#define IS_AKM_OPEN_ONLY(_AKMMap)		((_AKMMap) == (1 << SEC_AKM_OPEN))
#define IS_CIPHER_NONE_ONLY(_Cipher)    ((_Cipher) == (1 << SEC_CIPHER_NONE))
#define IS_SECURITY(_SecConfig)    ((!IS_AKM_OPEN_ONLY((_SecConfig)->AKMMap)) ||  (!IS_CIPHER_NONE_ONLY((_SecConfig)->PairwiseCipher)))
#define IS_NO_SECURITY(_SecConfig)    (IS_AKM_OPEN((_SecConfig)->AKMMap) &&  IS_CIPHER_NONE((_SecConfig)->PairwiseCipher))
#define IS_SECURITY_OPEN_WEP(_SecConfig)    (IS_AKM_OPEN((_SecConfig)->AKMMap)  && IS_CIPHER_WEP((_SecConfig)->PairwiseCipher))

#define IS_SECURITY_WPA2PSK_AES(_SecConfig)    ((IS_AKM_WPA2((_SecConfig)->AKMMap)  || IS_AKM_WPA2PSK((_SecConfig)->AKMMap))  \
		&& (IS_CIPHER_CCMP128((_SecConfig)->PairwiseCipher)))

#ifdef DOT1X_SUPPORT
#define IS_IEEE8021X(_SecConfig)     ((_SecConfig)->IEEE8021X == TRUE)
#endif


/* Need to remove --START */
#define IS_AKM_1X_Entry(_Entry)     (IS_AKM_WPA1((_Entry)->SecConfig.AKMMap)  \
									 || IS_AKM_WPA2((_Entry)->SecConfig.AKMMap) \
									 || IS_AKM_WPA3_192BIT((_Entry)->SecConfig.AKMMap))

#ifdef DOT1X_SUPPORT
#define IS_IEEE8021X_Entry(_Entry)     ((_Entry)->SecConfig.IEEE8021X == TRUE)
#endif

#define IS_AKM_WPA_CAPABILITY_Entry(_Entry)     (IS_AKM_WPA1((_Entry)->SecConfig.AKMMap)  \
		|| IS_AKM_WPA1PSK((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPANONE((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPA2((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPA2PSK((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPA2_SHA256((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPA2PSK_SHA256((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPA3_192BIT((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_WPA3PSK((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_DPP((_Entry)->SecConfig.AKMMap) \
		|| IS_AKM_OWE((_Entry)->SecConfig.AKMMap))

#define IS_AKM_PSK_Entry(_Entry)     (IS_AKM_WPA1PSK((_Entry)->SecConfig.AKMMap)  \
					  || IS_AKM_WPA2PSK((_Entry)->SecConfig.AKMMap) \
					  || IS_AKM_WPA3PSK((_Entry)->SecConfig.AKMMap) \
					  || IS_AKM_DPP((_Entry)->SecConfig.AKMMap) \
					  || IS_AKM_OWE((_Entry)->SecConfig.AKMMap))


#ifdef DOT11R_FT_SUPPORT
#undef IS_AKM_PSK_Entry
#define IS_AKM_PSK_Entry(_Entry) (IS_AKM_WPA1PSK((_Entry)->SecConfig.AKMMap)  \
								  || IS_AKM_WPA2PSK((_Entry)->SecConfig.AKMMap)   \
								  || IS_AKM_FT_WPA2PSK((_Entry)->SecConfig.AKMMap) \
								  || IS_AKM_WPA3PSK((_Entry)->SecConfig.AKMMap) \
									|| IS_AKM_DPP((_Entry)->SecConfig.AKMMap) \
								  || IS_AKM_FT_SAE_SHA256((_Entry)->SecConfig.AKMMap) \
								  || IS_AKM_OWE((_Entry)->SecConfig.AKMMap))
#endif /* DOT11R_FT_SUPPORT */

#define IS_AKM_FT_WPAPSKWPA2PSK_Entry(_Entry)		(IS_AKM_WPA1PSK((_Entry)->SecConfig.AKMMap)  \
		&& IS_AKM_WPA2PSK((_Entry)->SecConfig.AKMMap))

#define IS_SECURITY_Entry(_Entry)    (IS_SECURITY(&(_Entry)->SecConfig))
#define IS_AKM_WPA1_Entry(_Entry)                          (IS_AKM_WPA1((_Entry)->SecConfig.AKMMap))
#define IS_AKM_WPA1PSK_Entry(_Entry)                          (IS_AKM_WPA1PSK((_Entry)->SecConfig.AKMMap))
#define IS_AKM_WPA2_Entry(_Entry)                          (IS_AKM_WPA2((_Entry)->SecConfig.AKMMap))
#define IS_AKM_WPA2PSK_Entry(_Entry)                          (IS_AKM_WPA2PSK((_Entry)->SecConfig.AKMMap))
#define IS_AKM_WPA3_192BIT_Entry(_Entry)                          (IS_AKM_WPA3_192BIT((_Entry)->SecConfig.AKMMap))
#define IS_AKM_WPA3PSK_Entry(_Entry)                          (IS_AKM_WPA3PSK((_Entry)->SecConfig.AKMMap))
#define IS_AKM_DPP_Entry(_Entry)                          (IS_AKM_DPP((_Entry)->SecConfig.AKMMap))
#define IS_AKM_OWE_Entry(_Entry)                          (IS_AKM_OWE((_Entry)->SecConfig.AKMMap))
#define IS_CIPHER_WEP_Entry(_Entry)              (IS_CIPHER_WEP((_Entry)->SecConfig.PairwiseCipher))
#define IS_CIPHER_TKIP_Entry(_Entry)              (IS_CIPHER_TKIP((_Entry)->SecConfig.PairwiseCipher))
#define IS_CIPHER_AES_Entry(_Entry)              (IS_CIPHER_CCMP128((_Entry)->SecConfig.PairwiseCipher))

#define IS_CIPHER_NONE_OR_WEP_Entry(_Entry)  (IS_NO_SECURITY(&(_Entry)->SecConfig) || IS_CIPHER_WEP((_Entry)->SecConfig.PairwiseCipher))

#define IS_SECURITY_OPEN_NONE_Entry(_Entry)    (IS_NO_SECURITY(&(_Entry)->SecConfig))

#define IS_SECURITY_SHARED_WEP_Entry(_Entry)    (IS_AKM_SHARED((_Entry)->SecConfig.AKMMap)  && IS_CIPHER_WEP((_Entry)->SecConfig.PairwiseCipher))
#define IS_SECURITY_AUTOSWITCH_Entry(_Entry)    (IS_AKM_AUTOSWITCH((_Entry)->SecConfig.AKMMap)  && IS_CIPHER_WEP((_Entry)->SecConfig.PairwiseCipher))
#define IS_NO_SECURITY_Entry(_Entry)    (IS_AKM_OPEN((_Entry)->SecConfig.AKMMap) &&  IS_CIPHER_NONE((_Entry)->SecConfig.PairwiseCipher))

#define SET_AKM_OPEN_Entry(_Entry)               (SET_AKM_OPEN((_Entry)->SecConfig.AKMMap))
#define SET_CIPHER_NONE_Entry(_Entry)          (SET_CIPHER_NONE((_Entry)->SecConfig.PairwiseCipher))

/* Need to remove --END */

typedef enum _SEC_GROUP_REKEY_METHOD {
	SEC_GROUP_REKEY_DISABLE,
	SEC_GROUP_REKEY_TIME,
	SEC_GROUP_REKEY_PACKET,
	SEC_GROUP_REKEY_DISCONNECT,
	SEC_GROUP_REKEY_MAX /* Not a real mode, defined as upper bound */
} SEC_GROUP_REKEY_METHOD;

#define DEFAULT_GROUP_REKEY_INTERVAL   3600 /* one hour */
#define MAX_GROUP_REKEY_INTERVAL          0x3ffffff


typedef struct _HANDSHAKE_PROFILE {
	UINT16 ReasonCode;	/* Record 4way failed reason code */
	UCHAR AAddr[MAC_ADDR_LEN]; /* For nonce and key calculate */
	UCHAR SAddr[MAC_ADDR_LEN]; /* For nonce and key calculate */
	UCHAR ANonce[LEN_KEY_DESC_NONCE];
	UCHAR SNonce[LEN_KEY_DESC_NONCE];
	UCHAR GNonce[LEN_KEY_DESC_NONCE];
	UCHAR ReplayCounter[LEN_KEY_DESC_REPLAY];
	UINT8 WpaState;
	UINT8 GTKState;
	UCHAR MsgType; /*Record 4 way/2 way status for message retry judgement */
	UCHAR RSC[6];
	RALINK_TIMER_STRUCT MsgRetryTimer;
	UCHAR MsgRetryCounter;
	BOOLEAN AllowInsPTK;
} HANDSHAKE_PROFILE, *PHANDSHAKE_PROFILE;

typedef struct _SECURITY_CONFIG {
	UINT32 AKMMap;
	NDIS_802_11_AUTHENTICATION_MODE AuthType;
	/* WEP Key */
	SEC_KEY_INFO WepKey[SEC_KEY_NUM];

	/* Pairwise Key */
	UINT32 PairwiseCipher;
	UCHAR PairwiseKeyId;
#ifdef RT_CFG80211_SUPPORT
	UCHAR PairwiseKeyId_set_flag;
#endif
	UCHAR PSK[LEN_PSK + 1]; /* Add "\0" length */
	UCHAR PMK[LEN_MAX_PMK];
#ifdef MAP_R3
	UINT8 ptk_len;
	UINT8 pmk_len;
#endif /* MAP_R3 */
	UCHAR PTK[LEN_MAX_PTK]; /* 512 bits max, KCK(16)+KEK(16)+TK(32) */
	UINT8 ptk_Reinstall;
	UINT8 gtk_Reinstall;

	/* for Txblk reference and tx_sw_encrypt() can use */
	CIPHER_KEY SwPairwiseKey;
#ifdef SW_CONNECT_SUPPORT
#ifdef CONFIG_LINUX_CRYPTO
	struct crypto_aead *tfm;
#endif /* CONFIG_LINUX_CRYPTO */
#endif /* SW_CONNECT_SUPPORT */

	/* Group Key */
	UINT32 GroupCipher;
	UCHAR GroupKeyId;
#ifndef RT_CFG80211_SUPPORT
	UCHAR GMK[LEN_GMK];
#endif /*RT_CFG80211_SUPPORT*/
	UCHAR GTK[LEN_MAX_GTK];
#ifndef RT_CFG80211_SUPPORT
	/* Group Key control parameter */
	SEC_GROUP_REKEY_METHOD GroupReKeyMethod;
	ULONG GroupReKeyInterval; /* time-based: seconds, packet-based: kilo-packets */
	ULONG GroupPacketCounter;
	UCHAR GroupReKeyInstallCountDown; /*unit: second, Install key after 2 way completed or 1 seconds */
#endif /*RT_CFG80211_SUPPORT*/
	ULONG PMKCachePeriod;

	UINT8 key_deri_alg;

#ifndef RT_CFG80211_SUPPORT
	/* WPA/WPA2 4way database */
	RALINK_TIMER_STRUCT StartFor4WayTimer;
	RALINK_TIMER_STRUCT StartFor2WayTimer;
	RALINK_TIMER_STRUCT GroupRekeyTimer;
#endif /*RT_CFG80211_SUPPORT*/
	HANDSHAKE_PROFILE Handshake;
	RALINK_TIMER_STRUCT csa_disconnect_timer;
#ifndef RT_CFG80211_SUPPORT
	/* Dirty code for repeater */
	UINT STARec_Bssid;
#endif /*RT_CFG80211_SUPPORT*/
#ifdef DOT11W_PMF_SUPPORT
	PMF_CFG PmfCfg;
#endif /* DOT11W_PMF_SUPPORT */

#if defined(CONFIG_HOTSPOT) && defined(CONFIG_AP_SUPPORT)
	UCHAR HsUniGTK[LEN_MAX_GTK]; /* for storing HS DGAF uni GTK */
#endif /* defined(CONFIG_HOTSPOT) && defined(CONFIG_AP_SUPPORT) */

	/* 802.1x */
#if defined(DOT1X_SUPPORT) && !defined(RT_CFG80211_SUPPORT)
	UINT32 own_ip_addr;
	UINT32 own_radius_port;
	UINT32 retry_interval;
	UINT32 session_timeout_interval;
	UINT32 quiet_interval;
	UCHAR EAPifname[IFNAMSIZ];	/* indicate as the binding interface for EAP negotiation. */
	UCHAR EAPifname_len;
	UCHAR PreAuthifname[IFNAMSIZ];	/* indicate as the binding interface for WPA2 Pre-authentication. */
	UCHAR PreAuthifname_len;
	BOOLEAN PreAuth;
	UINT8 NasId[IFNAMSIZ];
	UINT8 NasIdLen;
	UCHAR radius_srv_num;
	RADIUS_SRV_INFO radius_srv_info[MAX_RADIUS_SRV_NUM];
#ifdef RADIUS_ACCOUNTING_SUPPORT
	UINT8 radius_acct_srv_num;
	RADIUS_SRV_INFO radius_acct_srv_info[MAX_RADIUS_SRV_NUM];
	/* int radius_request_cui; */
	int radius_acct_authentic;
	int acct_interim_interval;
	int acct_enable;
#endif /*RADIUS_ACCOUNTING_SUPPORT*/
#ifdef RADIUS_MAC_ACL_SUPPORT
	RT_802_11_RADIUS_ACL RadiusMacAuthCache;
	UINT32 RadiusMacAuthCacheTimeout;
#endif /* RADIUS_MAC_ACL_SUPPORT */
#endif /* DOT1X_SUPPORT */

	/* pmk cahce */
	UCHAR *pmkid;
	UCHAR *pmk_cache;

#if defined(DOT1X_SUPPORT)
	BOOLEAN IEEE8021X; /* Only indicate if we are running in dynamic WEP mode (WEP+802.1x) */
#endif

#ifdef DISABLE_HOSTAPD_BEACON
	UINT8   RsnCap[2];
#endif


	/* Encrypt EAPOL frames if session is present */
	BOOLEAN is_eapol_encrypted;
	/* IE for WPA1/WPA2/WAPI */
	SEC_RSNIE_TYPE RSNE_Type[SEC_RSNIE_NUM];
	UCHAR RSNE_EID[SEC_RSNIE_NUM][1];
	UCHAR RSNE_Len[SEC_RSNIE_NUM];
	UCHAR RSNE_Content[SEC_RSNIE_NUM][MAX_LEN_OF_RSNIE];
#ifndef RT_CFG80211_SUPPORT
	UCHAR BCN_RSNE_Len[SEC_RSNIE_NUM];
	UCHAR BCN_RSNE_Content[SEC_RSNIE_NUM][MAX_LEN_OF_RSNIE];
#endif /* RT_CFG80211_SUPPORT */
	UCHAR rsnxe_content[MAX_LEN_OF_RSNXEIE];
	UCHAR rsnxe_len;

#ifdef CFG_RSNO_SUPPORT
	/* RSNE/RSNXE override IE */
	UCHAR rsneo_content[MAX_LEN_OF_RSNIE];
	UCHAR rsneo_len;
	UCHAR rsnxeo_content[MAX_LEN_OF_RSNXEIE];
	UCHAR rsnxeo_len;
#endif /* CFG_RSNO_SUPPORT */

	UCHAR LastGroupKeyId;
	UCHAR LastGTK[LEN_MAX_GTK];
#if defined(CONFIG_OWE_SUPPORT) && !defined(RT_CFG80211_SUPPORT)
	OWE_INFO owe;
#endif /*CONFIG_OWE_SUPPORT*/
#if defined(DOT11_SAE_SUPPORT) || defined(SUPP_SAE_SUPPORT)
	UCHAR pwd_id_cnt;
	struct pwd_id_list pwd_id_list_head;
	struct sae_capability sae_cap;
	UCHAR sae_conn_type;
#ifndef RT_CFG80211_SUPPORT
	struct sae_pt *pt_list;
	struct sae_pk_cfg sae_pk;
#endif /* RT_CFG80211_SUPPORT */
#endif
#ifdef BCN_PROTECTION_SUPPORT
	struct bcn_protection_cfg bcn_prot_cfg;
	UINT8 Bigtk_Reinstall;
#endif
	UCHAR ft_only;
	UCHAR ocv_support; /* for pairwise entry, it should be marked as support only if both of ap and sta support it */
	UCHAR td_value_fixed_en;
	UCHAR td_value;
	UCHAR wait_csa_sa_query;
#ifdef APCLI_SUPPORT
	UCHAR apcli_ocv_support;	/* set 1 when enabled in dat file or set through iwpriv */
#endif
#if defined(APCLI_CFG80211_SUPPORT) && defined(SUPP_RANDOM_MAC_IN_DRIVER_SUPPORT)
	UCHAR wpa_supp_seq_num; /* 0= set SN +delta, 1= set SN by driver */
#endif

#ifdef CONFIG_HOTSPOT_R3
	BOOLEAN bIsWPA2EntOSEN;
#endif
} SECURITY_CONFIG, *PSECURITY_CONFIG;

/*	Bit	Name			Most secure algorithms						Transition algorithms
  *	0	WPA3-Persona	00-0F-AC:8 (SAE)							00-0F-AC:2 and 00-0F-AC:6 (PSK), and any other PSK AKMs
  *																00-0F-AC:4 (FT over PSK), and any other FT over PSK AKMs
  *	1	SAE-PK			00-0F-AC:8 (SAE) using SAE-PK				00-0F-AC:8 (SAE) not using SAE-PK, and 00-0F-AC:9 (FT over SAE) not using SAE-PK
  *																00-0F-AC:2 and 00-0F-AC:6 (PSK), and any other PSK AKMs
  *																00-0F-AC:4 (FT over PSK), and any other FT over PSK AKMs
  *	2	WPA3-Enterprise	00-0F-AC:1 and 00-0F-AC:5 (IEEE 802.1X)	None
  *	3	Enhanced Open	00-0F-AC:18 (OWE)						Open System authentication without encryption
  */
struct transition_disable_bitmap {
#ifdef CFG_BIG_ENDIAN
	UINT8	rsv:4;
	UINT8	enhanced_open:1;
	UINT8	wpa3_ent:1;
	UINT8	sae_pk:1;
	UINT8	wpa3_psk:1;
#else
	UINT8	wpa3_psk:1;
	UINT8	sae_pk:1;
	UINT8	wpa3_ent:1;
	UINT8	enhanced_open:1;
	UINT8	rsv:4;
#endif /* CFG_BIG_ENDIAN */
};

struct key_data_element_ptr {
	UCHAR *rsne_ptr;
	UCHAR *rsnxe_ptr;
	UCHAR *ftie_ptr;
	UCHAR *mdie_ptr;
	UCHAR *gtk_kde_ptr;
	UCHAR *igtk_kde_ptr;
	UCHAR *bigtk_kde_ptr;
	UCHAR *oci_kde_ptr;
	UCHAR *osen_ptr;
	UCHAR *wpa_ie_ptr;
	UCHAR *tti_kde_ptr;
#ifdef DPP_SUPPORT
	UCHAR *dpp_ptr;
#endif
	UCHAR *mac_addr_kde_ptr;
	UCHAR *mlo_link_kde_ptr[MLD_LINK_MAX];
	UCHAR mlo_link_num;
	UCHAR *mlo_gtk_kde_ptr[MLD_LINK_MAX];
	UCHAR mlo_gtk_num;
	UCHAR *mlo_igtk_kde_ptr[MLD_LINK_MAX];
	UCHAR mlo_igtk_num;
	UCHAR *mlo_bigtk_kde_ptr[MLD_LINK_MAX];
	UCHAR mlo_bigtk_num;
};

enum {
	RSNE_PRESNET = 1 << 0,
	RSNXE_PRESNET = 1 << 1,
	GTK_PRESNET = 1 << 2,
	OCI_PRESNET = 1 << 3,
	MDIE_PRESNET = 1 << 4,
	FTIE_PRESNET = 1 << 5,
	TIE_PRESNET = 1 << 6,
	TTI_PRESNET = 1 << 7,
	MAC_ADDR_PRESNET = 1 << 8,
	MLO_LINK_PRESNET = 1 << 9,
	MLO_GTK_PRESNET = 1 << 10,
};

/*******************************************************
   Security support by feature and wireless mode
  *******************************************************/

#ifdef CONFIG_AP_SUPPORT
/* List AP support AKMs */
#define AKM_AP_MASK     ((1 << SEC_AKM_WPA1) \
						 | (1 << SEC_AKM_WPA1PSK) \
						 | (1 << SEC_AKM_WPA2) \
						 | (1 << SEC_AKM_WPA2PSK) \
						 | (1 << SEC_AKM_WAICERT) \
						 | (1 << SEC_AKM_WAIPSK) \
						 | (1 << SEC_AKM_FT_WPA2PSK) \
						 | (1 << SEC_AKM_SAE_SHA256) \
						 | (1 << SEC_AKM_SUITEB_SHA384) \
						 | (1 << SEC_AKM_DPP) \
						 | (1 << SEC_AKM_OWE) \
						 | (1 << SEC_AKM_SAE_EXT) \
						 | (1 << SEC_AKM_FT_SAE_EXT) \
						)
#endif /* CONFIG_AP_SUPPORT */


#ifdef CONFIG_STA_SUPPORT
/* List STA support AKMs */
#define AKM_STA_MASK     ((1 << SEC_AKM_WPA1) \
						  | (1 << SEC_AKM_WPA1PSK) \
						  | (1 << SEC_AKM_WPANone) \
						  | (1 << SEC_AKM_WPA2) \
						  | (1 << SEC_AKM_WPA2PSK) \
						  | (1 << SEC_AKM_WAICERT) \
						  | (1 << SEC_AKM_WAIPSK) \
						  | (1 << SEC_AKM_SAE_SHA256) \
						  | (1 << SEC_AKM_SUITEB_SHA384) \
						  | (1 << SEC_AKM_DPP) \
						  | (1 << SEC_AKM_OWE) \
						  | (1 << SEC_AKM_SAE_EXT) \
						 )
#endif /* CONFIG_STA_SUPPORT */


#ifdef APCLI_SUPPORT
/* List apcli support AKMs and Ciphers */
#define AKM_APCLI_MASK     ((1 << SEC_AKM_WPA1PSK) \
							| (1 << SEC_AKM_WPA2PSK)\
							| (1 << SEC_AKM_SAE_SHA256)\
							| (1 << SEC_AKM_DPP) \
							| (1 << SEC_AKM_OWE))
#endif /* APCLI_SUPPORT */
/*to support 32 bss, 600 -> 1200*/
#define MAX_PARAMETER_LEN  1200 /* worse case: WEP128 for MBSS0~15 = (32+1)*16=528 */
UCHAR sec_get_cipher_key_len(UINT32 cipher);
#endif /* SEC_CMM_H */

